import socket       # For connecting to the target service
import threading    # For running the check without freezing the GUI
import time         # For measuring response time
import tkinter as tk # For GUI interface
from tkinter import messagebox
import re           # For cleaning HTML tags

# -------- Service Detection Logic --------
def detect_service(port, banner):
    banner_lower = banner.lower()
    if port in (80, 8080) or "http" in banner_lower:
        return "HTTP Web Server"
    elif port == 21 or "ftp" in banner_lower:
        return "FTP Server"
    elif port == 22 or "ssh" in banner_lower:
        return "SSH Server"
    elif port == 25 or "smtp" in banner_lower:
        return "SMTP Mail Server"
    else:
        return "Unknown / Custom Service"

# -------- Connection & Banner Grab --------
def check_service(ip, port, result_label):
    # Clear previous result immediately
    result_label.config(text="Checking...", fg="blue")

    try:
        start_time = time.time()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)
        sock.connect((ip, port))
        sock.sendall(b"\n")  # Trigger a banner if possible
        banner = sock.recv(1024).decode(errors="ignore").strip()
        sock.close()
        end_time = time.time()

        # Clean banner: remove HTML tags if any
        banner_clean = re.sub('<[^<]+?>', '', banner)
        banner_short = banner_clean[:300] if banner_clean else "No banner"

        service_type = detect_service(port, banner_short)
        response_time = round((end_time - start_time) * 1000, 2)

        result_text = f"Service: {service_type}\nBanner: {banner_short}\nResponse Time: {response_time} ms"
        result_label.config(text=result_text, fg="green")
    except Exception as e:
        result_label.config(text=f"Connection failed: {e}", fg="red")

# -------- Thread Starter --------
def start_check(ip_entry, port_entry, result_label):
    try:
        ip = ip_entry.get().strip()
        port = int(port_entry.get().strip())
        if not ip:
            messagebox.showwarning("Input Error", "Please enter a valid IP address or hostname.")
            return
        threading.Thread(target=check_service, args=(ip, port, result_label), daemon=True).start()
    except ValueError:
        messagebox.showerror("Input Error", "Port must be a number.")

# -------- GUI Setup --------
root = tk.Tk()
root.title("Network Service Info Card")
root.geometry("400x250")
root.resizable(False, False)

tk.Label(root, text="IP Address / Hostname:").pack(pady=5)
ip_entry = tk.Entry(root, width=30)
ip_entry.pack()

tk.Label(root, text="Port:").pack(pady=5)
port_entry = tk.Entry(root, width=10)
port_entry.pack()

result_label = tk.Label(root, text="Enter details and click Check", wraplength=350, justify="left", fg="blue")
result_label.pack(pady=15)

check_button = tk.Button(root, text="Check Service", command=lambda: start_check(ip_entry, port_entry, result_label))
check_button.pack()

root.mainloop()
